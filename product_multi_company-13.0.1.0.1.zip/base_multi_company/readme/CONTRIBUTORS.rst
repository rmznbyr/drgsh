* Dave Lasley <dave@laslabs.com>
* Pedro M. Baeza <pedro.baeza@tecnativa.com>
* Laurent Mignon <laurent.mignon@acsone.eu>
* Cédric Pigeon <cedric.pigeon@acsone.eu>
* Rodrigo Ferreira <rodrigosferreira91@gmail.com>
* Florian da Costa <florian.dacosta@akretion.com>
