This module provides an abstract model to be inherited by models that need
to implement multi-company functionality.

No direct functionality is provided by this module.
